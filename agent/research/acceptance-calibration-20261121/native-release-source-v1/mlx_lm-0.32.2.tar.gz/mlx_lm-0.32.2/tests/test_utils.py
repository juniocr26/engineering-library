# Copyright © 2024 Apple Inc.

import dataclasses
import json
import os
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

import mlx.core as mx
import mlx.nn as nn
from mlx.utils import tree_flatten

from mlx_lm import convert, utils

HF_MODEL_PATH = "mlx-community/Qwen1.5-0.5B-Chat-4bit"


class TestUtils(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.test_dir_fid = tempfile.TemporaryDirectory()
        cls.test_dir = cls.test_dir_fid.name
        if not os.path.isdir(cls.test_dir):
            os.mkdir(cls.test_dir_fid.name)

    @classmethod
    def tearDownClass(cls):
        cls.test_dir_fid.cleanup()

    def test_load(self):
        from mlx_lm.models.qwen2 import Model as Qwen2Model

        model, _ = utils.load(HF_MODEL_PATH)
        self.assertIsInstance(model, Qwen2Model)

        model_lazy, _ = utils.load(HF_MODEL_PATH, lazy=True)

        mx.eval(model_lazy.parameters())

        p1 = model.layers[0].mlp.up_proj.weight
        p2 = model_lazy.layers[0].mlp.up_proj.weight
        self.assertTrue(mx.allclose(p1, p2))

    def test_load_config_decodes_tagged_floats(self):
        # transformers tags non-finite floats so that config.json stays valid
        # JSON for every parser; the tag has to be undone on the way back in.
        model_path = Path(self.test_dir) / "tagged-floats"
        model_path.mkdir(exist_ok=True)
        with open(model_path / "config.json", "w") as f:
            json.dump(
                {
                    "model_type": "nemotron_h",
                    "time_step_limit": [0.0, {"__float__": "Infinity"}],
                    "nested": {"lower": {"__float__": "-Infinity"}},
                    "not_a_tag": {"__float__": 3, "other": 4},
                },
                f,
            )

        config = utils.load_config(model_path)
        self.assertEqual(config["time_step_limit"], [0.0, float("inf")])
        self.assertEqual(config["nested"]["lower"], float("-inf"))
        self.assertEqual(config["not_a_tag"], {"__float__": 3, "other": 4})

        # Saving tags them again, so a converted model keeps a config.json that
        # any JSON parser can read, and reading it back gives the same floats.
        utils.save_config(config, model_path / "config.json")
        with open(model_path / "config.json") as f:
            self.assertEqual(
                json.load(f)["time_step_limit"], [0.0, {"__float__": "Infinity"}]
            )
        self.assertEqual(
            utils.load_config(model_path)["time_step_limit"], config["time_step_limit"]
        )

    def test_make_shards(self):
        from mlx_lm.models import llama

        args = llama.ModelArgs(
            model_type="llama",
            hidden_size=2048,
            num_hidden_layers=32,
            intermediate_size=4096,
            num_attention_heads=32,
            rms_norm_eps=1e-5,
            vocab_size=30_000,
        )
        model = llama.Model(args)
        weights = tree_flatten(model.parameters())
        gb = sum(p.nbytes for _, p in weights) // 2**30
        shards = utils.make_shards(dict(weights), 1)
        self.assertTrue(gb <= len(shards) <= gb + 1)

    def test_make_shards_oversized_weight(self):
        # make_shards only reads .nbytes, so fake the sizes.
        small = SimpleNamespace(nbytes=1 << 20)
        big = SimpleNamespace(nbytes=(1 << 30) + 1)
        for weights, expected in (
            ({}, []),
            ({"a": big}, [{"a": big}]),
            (
                {"a": small, "b": big, "c": small},
                [{"a": small}, {"b": big}, {"c": small}],
            ),
        ):
            self.assertEqual(utils.make_shards(weights, 1), expected)

    def test_parse_size(self):
        self.assertEqual(utils._parse_size("1024"), 1024)
        self.assertEqual(utils._parse_size("20G"), 20_000_000_000)
        self.assertEqual(utils._parse_size("512M"), 512_000_000)
        self.assertEqual(utils._parse_size("4.1MB"), 4_100_000)
        self.assertEqual(utils._parse_size("4.1M"), 4_100_000)
        self.assertEqual(utils._parse_size("4.1GB"), 4_100_000_000)
        self.assertEqual(utils._parse_size("8.2MB"), 8_200_000)
        self.assertEqual(utils._parse_size("16.9GB"), 16_900_000_000)
        self.assertEqual(utils._parse_size("2.7GB"), 2_700_000_000)

    def test_quantize(self):
        from mlx_lm.models import llama

        args = llama.ModelArgs(
            model_type="llama",
            hidden_size=1024,
            num_hidden_layers=4,
            intermediate_size=2048,
            num_attention_heads=4,
            rms_norm_eps=1e-5,
            vocab_size=10_000,
        )
        model = llama.Model(args)
        model, config = utils.quantize_model(model, {}, 64, 4)
        weights = dict(tree_flatten(model.parameters()))
        self.assertTrue("model.layers.2.mlp.up_proj.scales" in weights)
        self.assertTrue("model.layers.2.mlp.up_proj.biases" in weights)
        self.assertEqual(config["quantization"]["group_size"], 64)
        self.assertEqual(config["quantization"]["bits"], 4)

    def test_convert(self):
        mlx_path = os.path.join(self.test_dir, "mlx_model")

        convert(HF_MODEL_PATH, mlx_path=mlx_path, quantize=False)
        model, _ = utils.load(mlx_path)
        self.assertTrue(isinstance(model.layers[0].mlp.up_proj, nn.QuantizedLinear))
        self.assertTrue(isinstance(model.layers[-1].mlp.up_proj, nn.QuantizedLinear))

        # Check model weights have right type
        mlx_path = os.path.join(self.test_dir, "mlx_model_bf16")
        convert(HF_MODEL_PATH, mlx_path=mlx_path, dtype="bfloat16")
        model, _ = utils.load(mlx_path)

        self.assertEqual(model.layers[0].mlp.up_proj.scales.dtype, mx.bfloat16)
        self.assertEqual(model.layers[-1].mlp.up_proj.scales.dtype, mx.bfloat16)

    def test_load_model_with_custom_get_classes(self):
        class CustomQwenModel(nn.Module):
            def __init__(self, args):
                super().__init__()
                self.config = args
                self.custom_attribute = "This is a custom model"

            def load_weights(self, weights, **kwargs):
                self.qwenWeights = weights

        class CustomQwenConfig:
            @classmethod
            def from_dict(cls, config):
                instance = cls()
                for k, v in config.items():
                    setattr(instance, k, v)
                return instance

        def custom_get_classes(config):
            return CustomQwenModel, CustomQwenConfig

        model_path = utils.hf_repo_to_path(HF_MODEL_PATH)
        model, _ = utils.load_model(model_path, get_model_classes=custom_get_classes)

        self.assertIsInstance(model, CustomQwenModel)
        self.assertTrue(hasattr(model, "custom_attribute"))
        self.assertEqual(model.custom_attribute, "This is a custom model")
        self.assertTrue(hasattr(model, "qwenWeights"))

    def test_get_classes_remaps_bailing_v3_architecture(self):
        from mlx_lm.models import bailing_moe_v3

        model_cls, args_cls = utils._get_classes(
            {
                "model_type": "bailing_hybrid",
                "architectures": ["BailingMoeV3ForCausalLM"],
            }
        )

        self.assertIs(model_cls, bailing_moe_v3.Model)
        self.assertIs(args_cls, bailing_moe_v3.ModelArgs)

    def test_load_model_gemma4_with_per_layer_projection_quantization(self):
        from mlx_lm.models import gemma4

        args = gemma4.ModelArgs.from_dict(
            {
                "model_type": "gemma4",
                "vocab_size": 32,
                "text_config": {
                    "model_type": "gemma4_text",
                    "hidden_size": 32,
                    "num_hidden_layers": 2,
                    "intermediate_size": 64,
                    "num_attention_heads": 2,
                    "num_key_value_heads": 1,
                    "num_global_key_value_heads": 1,
                    "head_dim": 16,
                    "global_head_dim": 16,
                    "sliding_window": 8,
                    "sliding_window_pattern": 1,
                    "layer_types": ["full_attention", "full_attention"],
                    "hidden_size_per_layer_input": 32,
                    "vocab_size_per_layer_input": 32,
                    "num_kv_shared_layers": 0,
                    "tie_word_embeddings": True,
                },
            }
        )
        model = gemma4.Model(args)
        model, config = utils.quantize_model(
            model,
            {
                "model_type": "gemma4",
                "vocab_size": args.vocab_size,
                "text_config": args.text_config,
            },
            group_size=32,
            bits=4,
        )

        config["quantization"]["language_model.model.per_layer_model_projection"] = {
            "group_size": 32,
            "bits": 4,
        }

        with tempfile.TemporaryDirectory(dir=self.test_dir) as mlx_path:
            utils.save_model(mlx_path, model)
            utils.save_config(config, os.path.join(mlx_path, "config.json"))

            loaded, loaded_config = utils.load_model(Path(mlx_path))

            self.assertIn(
                "language_model.model.per_layer_model_projection",
                loaded_config["quantization"],
            )

            logits = loaded(mx.array([[1, 2, 3]], dtype=mx.int32))
            mx.eval(logits)
            self.assertEqual(logits.shape, (1, 3, args.vocab_size))

    def test_infer_quant_config(self):
        from mlx_lm.models.mla import MultiLinear

        for mode, bits, group_size in [
            ("affine", 3, 64),
            ("affine", 4, 32),
            ("affine", 8, 128),
            ("mxfp4", 4, 32),
            ("mxfp8", 8, 32),
            ("nvfp4", 4, 16),
        ]:
            for name, layer in [
                ("linear", nn.Linear(256, 128, bias=False)),
                ("multi_linear", MultiLinear(256, 128, 4)),
            ]:
                with self.subTest(
                    mode=mode, bits=bits, group_size=group_size, layer=name
                ):
                    q = layer.to_quantized(group_size=group_size, bits=bits, mode=mode)
                    weights = {"l.weight": q.weight, "l.scales": q.scales}
                    self.assertEqual(
                        utils.infer_quant_config("l", layer, weights),
                        {"group_size": group_size, "bits": bits, "mode": mode},
                    )

    def test_infer_quant_config_unknown_packing(self):
        # uint8 scales say the weight is not affine, but no mode packs 6 bits
        # into groups of 64.
        layer = nn.Linear(256, 128, bias=False)
        weights = {
            "l.weight": mx.zeros((128, 48), mx.uint32),
            "l.scales": mx.zeros((128, 4), mx.uint8),
        }
        with self.assertRaises(ValueError):
            utils.infer_quant_config("l", layer, weights)

    def test_load_model_with_mixed_bit_derived_mla_projection(self):
        # deepseek_v3's sanitize() derives embed_q/unembed_out from kv_b_proj at
        # its bits, but those paths never reach config["quantization"], so
        # load_model has to infer them instead of using the global default.
        from mlx_lm.models import deepseek_v3

        args = deepseek_v3.ModelArgs(
            vocab_size=64,
            hidden_size=32,
            intermediate_size=64,
            moe_intermediate_size=64,
            num_hidden_layers=1,
            num_attention_heads=2,
            num_key_value_heads=2,
            n_routed_experts=2,
            kv_lora_rank=32,
            q_lora_rank=32,
            qk_rope_head_dim=32,
            v_head_dim=32,
            qk_nope_head_dim=32,
        )
        model = deepseek_v3.Model(args)
        # The derived projections use a different mode than the rest of the
        # model, so load_model has to infer the mode too, not just the bits.
        group_size, bits, mode = 32, 4, "mxfp4"
        derived_bits, derived_mode = 8, "mxfp8"
        model, config = utils.quantize_model(
            model,
            dataclasses.asdict(args),
            group_size=group_size,
            bits=bits,
            mode=mode,
        )

        # Re-pack the derived projections, as a per-tensor override on kv_b_proj
        # would, leaving config["quantization"] untouched.
        attn = model.layers[0].self_attn
        for proj in (attn.embed_q, attn.unembed_out):
            w = mx.dequantize(
                proj.weight,
                proj.scales,
                group_size=proj.group_size,
                bits=proj.bits,
                mode=proj.mode,
            )
            proj.weight, proj.scales = mx.quantize(
                w, group_size=group_size, bits=derived_bits, mode=derived_mode
            )

        with tempfile.TemporaryDirectory(dir=self.test_dir) as mlx_path:
            utils.save_model(mlx_path, model)
            utils.save_config(config, os.path.join(mlx_path, "config.json"))
            self.assertEqual(
                config["quantization"],
                {"group_size": group_size, "bits": bits, "mode": mode},
            )

            loaded, _ = utils.load_model(Path(mlx_path))

            loaded_attn = loaded.layers[0].self_attn
            for proj in (loaded_attn.embed_q, loaded_attn.unembed_out):
                self.assertEqual(
                    (proj.bits, proj.group_size, proj.mode),
                    (derived_bits, group_size, derived_mode),
                )


CUSTOM_MODEL_FILE = """\
from pathlib import Path

import mlx.nn as nn

(Path(__file__).parent / "side_effect.txt").write_text("executed")


class ModelArgs:
    @classmethod
    def from_dict(cls, params):
        return cls()


class Model(nn.Module):
    def __init__(self, args):
        super().__init__()
        self.linear = nn.Linear(8, 8)

    def __call__(self, x):
        return self.linear(x)
"""


class TestTrustRemoteCode(unittest.TestCase):
    def setUp(self):
        self.model_dir_fid = tempfile.TemporaryDirectory()
        self.model_path = Path(self.model_dir_fid.name)

    def tearDown(self):
        self.model_dir_fid.cleanup()

    @property
    def _side_effect_file(self) -> Path:
        return self.model_path / "side_effect.txt"

    def _write_custom_model_dir(self):
        config = {"model_type": "custom", "model_file": "arch.py"}
        with open(self.model_path / "config.json", "w") as f:
            json.dump(config, f)
        (self.model_path / "arch.py").write_text(CUSTOM_MODEL_FILE)
        mx.save_safetensors(
            str(self.model_path / "model.safetensors"),
            {"linear.weight": mx.zeros((8, 8)), "linear.bias": mx.zeros((8,))},
        )

    def test_model_file_blocked_by_default(self):
        """load_model must refuse to execute a custom model_file by default."""
        self._write_custom_model_dir()
        with self.assertRaises(ValueError) as cm:
            utils.load_model(self.model_path)
        self.assertIn("trust_remote_code", str(cm.exception))
        self.assertFalse(self._side_effect_file.exists())

    def test_model_file_loads_with_trust_remote_code(self):
        """Passing trust_remote_code=True opts in to executing model_file."""
        self._write_custom_model_dir()
        model, config = utils.load_model(self.model_path, trust_remote_code=True)
        self.assertIsInstance(model, nn.Module)
        self.assertEqual(config["model_file"], "arch.py")
        self.assertTrue(self._side_effect_file.exists())

    def test_normal_model_unaffected_by_default(self):
        """Models without model_file load fine with default arguments."""
        config = {
            "model_type": "llama",
            "hidden_size": 32,
            "num_hidden_layers": 1,
            "intermediate_size": 64,
            "num_attention_heads": 4,
            "num_key_value_heads": 4,
            "rms_norm_eps": 1e-5,
            "vocab_size": 64,
        }
        with open(self.model_path / "config.json", "w") as f:
            json.dump(config, f)
        model, loaded_config = utils.load_model(self.model_path, strict=False)
        self.assertIsInstance(model, nn.Module)
        self.assertEqual(loaded_config["model_type"], "llama")

    def test_compressed_tensors_known_formats(self):
        self.assertEqual(
            utils._compressed_tensors_quantization({"format": "nvfp4-pack-quantized"}),
            {"group_size": 16, "bits": 4, "mode": "nvfp4"},
        )
        self.assertEqual(
            utils._compressed_tensors_quantization({"format": "mxfp4-pack-quantized"}),
            {"group_size": 32, "bits": 4, "mode": "mxfp4"},
        )
        self.assertEqual(
            utils._compressed_tensors_quantization({"format": "pack-quantized"}),
            {"group_size": 32, "bits": 4, "mode": "affine"},
        )

    def test_compressed_tensors_float_quantized_is_rejected(self):
        with self.assertRaisesRegex(ValueError, "float-quantized"):
            utils._compressed_tensors_quantization({"format": "float-quantized"})


if __name__ == "__main__":
    unittest.main()
